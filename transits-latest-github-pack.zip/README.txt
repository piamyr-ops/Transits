TRANSITS — LATEST GITHUB PAGES PACK

Includes:
- index.html: latest game, large menu tutorial button fixed, animations, referee and modes
- sw.js: automatic offline app-shell caching with updated cache version

DEPLOY:
1. Open https://github.com/piamyr-ops/Transits
2. Upload both files to the same folder where your existing GitHub Pages index.html lives (usually repository root). Replace the existing index.html and sw.js.
3. Commit changes.
4. Open https://piamyr-ops.github.io/Transits/ after GitHub Pages deploys.
5. If an older version persists, refresh/reopen once while online to update the offline cache.

No installation inside the game menus is needed. Offline reopening requires a successful online visit first.
